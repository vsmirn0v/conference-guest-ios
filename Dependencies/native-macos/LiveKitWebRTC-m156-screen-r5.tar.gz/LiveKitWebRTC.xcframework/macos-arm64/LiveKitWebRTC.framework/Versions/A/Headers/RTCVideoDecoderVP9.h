/*
 *  Copyright 2017 The WebRTC project authors. All Rights Reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS.  All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#import <Foundation/Foundation.h>

#import <LiveKitWebRTC/RTCVideoCodecInfo.h>
#import <LiveKitWebRTC/RTCVideoDecoder.h>
#import <LiveKitWebRTC/RTCMacros.h>

NS_ASSUME_NONNULL_BEGIN

RTC_OBJC_EXPORT
@interface RTC_OBJC_TYPE (RTCVideoDecoderVP9) : NSObject

/* This returns a VP9 decoder that can be returned from a RTCVideoDecoderFactory injected into
 * RTCPeerConnectionFactory. Even though it implements the RTCVideoDecoder protocol, it can not be
 * used independently from the RTCPeerConnectionFactory.
 */
+ (id<RTC_OBJC_TYPE(RTCVideoDecoder)>)vp9Decoder;

/** Returns a factory-only VP9 decoder with per-stream software fallback.
 * Return a fresh handle from each createDecoder: call; it cannot be decoded
 * directly. hardwareDecoder must be a concrete hardware-only implementation,
 * not another factory-only native decoder. Pass nil for software-only decoding.
 * The native bridge rejects spatial SVC before invoking hardwareDecoder and
 * retries the original encoded image in libvpx. Hardware must return -13
 * (WEBRTC_VIDEO_CODEC_FALLBACK_SOFTWARE) for permanent incompatibility, without
 * emitting a frame for that input. Delta-frame recovery can require a keyframe.
 * releaseDecoder must stop callbacks before returning. No room reconnect is
 * required, and fallback affects only this decoder instance.
 */
+ (id<RTC_OBJC_TYPE(RTCVideoDecoder)>)vp9DecoderWithHardwareDecoder:
    (nullable id<RTC_OBJC_TYPE(RTCVideoDecoder)>)hardwareDecoder
    NS_SWIFT_NAME(vp9Decoder(hardwareDecoder:));

/** Returns the list of supported codec formats (profiles) for the VP9 decoder.
 */
+ (NSArray<RTC_OBJC_TYPE(RTCVideoCodecInfo) *> *)supportedCodecs;

+ (bool)isSupported;

@end

NS_ASSUME_NONNULL_END
